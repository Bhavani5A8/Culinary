import React, { useState, useEffect, useMemo } from 'react';
import { Award, Grid, List, Filter, TrendingUp, Clock, Users, Star, Heart, Bookmark, Eye, Zap } from 'lucide-react';
import RecipeCard from './RecipeCard';
import { featuredRecipes } from './recipeData';

// NEW ENHANCEMENT COMPONENTS - Additive layers
// In FeaturedRecipes.js  
import { 
  EnhancedRecipeCard, 
  SmartFilterPanel,  
} from './enhanced.js';

const FeaturedRecipes = ({ 
  onRecipeClick, 
  // NEW PROPS - Enhanced features (backward compatible)
  kitchenMode = false,
  searchFilters = {},
  enhancedFeatures = {}
}) => {
  // EXISTING STATE - Preserved
  const [filteredRecipes, setFilteredRecipes] = useState(featuredRecipes);
  
  // NEW ENHANCEMENT STATE - Additive layer
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'list' | 'compact'
  const [sortBy, setSortBy] = useState('rating'); // 'rating' | 'time' | 'difficulty' | 'cost'
  const [activeFilters, setActiveFilters] = useState({
    difficulty: '',
    maxTime: '',
    cuisine: '',
    dietary: '',
    priceRange: ''
  });
  const [showComparison, setShowComparison] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState([]);
  const [userFavorites, setUserFavorites] = useState(new Set());
  const [userBookmarks, setUserBookmarks] = useState(new Set());
  const [recipeViews, setRecipeViews] = useState({});

  // NEW ENHANCEMENT EFFECT - Load user data
  useEffect(() => {
    try {
      // Load user favorites and bookmarks (new functionality)
      const favorites = JSON.parse(sessionStorage.getItem('userFavorites') || '[]');
      const bookmarks = JSON.parse(sessionStorage.getItem('userBookmarks') || '[]');
      const views = JSON.parse(sessionStorage.getItem('recipeViews') || '{}');
      
      setUserFavorites(new Set(favorites));
      setUserBookmarks(new Set(bookmarks));
      setRecipeViews(views);
    } catch (error) {
      console.error('Error loading user data:', error);
      // Graceful fallback - continue without personalization
    }
  }, []);

  // NEW ENHANCEMENT EFFECT - Apply search filters
  useEffect(() => {
    try {
      if (searchFilters.query || Object.keys(searchFilters).length > 1) {
        const filtered = featuredRecipes.filter(recipe => {
          // Text search
          if (searchFilters.query) {
            const query = searchFilters.query.toLowerCase();
            const matchesText = recipe.title.toLowerCase().includes(query) ||
                               recipe.description.toLowerCase().includes(query) ||
                               recipe.ingredients?.some(ing => ing.toLowerCase().includes(query));
            if (!matchesText) return false;
          }
          
          // Filter by difficulty
          if (searchFilters.difficulty && recipe.difficulty !== searchFilters.difficulty) {
            return false;
          }
          
          // Filter by cuisine
          if (searchFilters.cuisine && recipe.cuisine !== searchFilters.cuisine) {
            return false;
          }
          
          return true;
        });
        
        setFilteredRecipes(filtered);
      } else {
        setFilteredRecipes(featuredRecipes);
      }
    } catch (error) {
      console.error('Error applying search filters:', error);
      setFilteredRecipes(featuredRecipes); // Fallback to all recipes
    }
  }, [searchFilters]);

  // NEW ENHANCEMENT MEMOIZED VALUE - Smart sorting
  const sortedAndFilteredRecipes = useMemo(() => {
    try {
      let recipes = [...filteredRecipes];

      // Apply enhanced filters
      recipes = recipes.filter(recipe => {
        if (activeFilters.difficulty && recipe.difficulty !== activeFilters.difficulty) return false;
        if (activeFilters.cuisine && recipe.cuisine !== activeFilters.cuisine) return false;
        if (activeFilters.maxTime) {
          const totalTime = parseInt(recipe.prepTime) + parseInt(recipe.cookTime || '0');
          if (totalTime > parseInt(activeFilters.maxTime)) return false;
        }
        return true;
      });

      // Apply sorting
      recipes.sort((a, b) => {
        switch (sortBy) {
          case 'rating':
            return (b.rating || 0) - (a.rating || 0);
          case 'time':
            const aTime = parseInt(a.prepTime) + parseInt(a.cookTime || '0');
            const bTime = parseInt(b.prepTime) + parseInt(b.cookTime || '0');
            return aTime - bTime;
          case 'difficulty':
            const difficultyOrder = { 'beginner': 1, 'intermediate': 2, 'advanced': 3 };
            return (difficultyOrder[a.difficulty] || 2) - (difficultyOrder[b.difficulty] || 2);
          case 'cost':
            return (a.estimatedCost || 0) - (b.estimatedCost || 0);
          default:
            return 0;
        }
      });

      return recipes;
    } catch (error) {
      console.error('Error sorting recipes:', error);
      return filteredRecipes; // Fallback to unfiltered recipes
    }
  }, [filteredRecipes, activeFilters, sortBy]);

  // FIXED: Recipe click handler with enhanced logging and error handling
  const handleRecipeClick = (recipeId) => {
    console.log('🔍 FeaturedRecipes.js - Recipe clicked:', recipeId);
    console.log('🔗 FeaturedRecipes.js - onRecipeClick prop:', onRecipeClick);
    console.log('📍 FeaturedRecipes.js - onRecipeClick type:', typeof onRecipeClick);
    
    try {
      if (onRecipeClick && recipeId) {
        // NEW ENHANCEMENT - Track recipe views
        const newViews = { ...recipeViews, [recipeId]: (recipeViews[recipeId] || 0) + 1 };
        setRecipeViews(newViews);
        sessionStorage.setItem('recipeViews', JSON.stringify(newViews));
        
        console.log('✅ FeaturedRecipes.js - Calling parent onRecipeClick with ID:', recipeId);
        // FIXED: Ensure we pass the recipe ID correctly
        onRecipeClick(recipeId);
      } else {
        console.error('❌ FeaturedRecipes.js - Missing onRecipeClick prop or recipeId');
        console.log('🔧 FeaturedRecipes.js - onRecipeClick available:', !!onRecipeClick);
        console.log('🔧 FeaturedRecipes.js - recipeId available:', !!recipeId);
        
        // FIXED: Enhanced fallback for missing onClick
        const recipe = sortedAndFilteredRecipes.find(r => r.id === recipeId);
        if (recipe) {
          alert(`Recipe: ${recipe.title}\n\nSorry, the recipe modal is not properly connected. This is a fallback display.\n\nPlease check that the parent component is passing the onRecipeClick prop correctly.`);
        } else {
          alert('Recipe not found or click handler not connected properly.');
        }
      }
    } catch (error) {
      console.error('💥 FeaturedRecipes.js - Error in handleRecipeClick:', error);
      alert('Error opening recipe. Please try again.');
    }
  };

  // NEW ENHANCED HANDLERS - Additive functionality
  const handleToggleFavorite = (recipeId) => {
    try {
      const newFavorites = new Set(userFavorites);
      if (newFavorites.has(recipeId)) {
        newFavorites.delete(recipeId);
      } else {
        newFavorites.add(recipeId);
      }
      setUserFavorites(newFavorites);
      sessionStorage.setItem('userFavorites', JSON.stringify([...newFavorites]));
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const handleToggleBookmark = (recipeId) => {
    try {
      const newBookmarks = new Set(userBookmarks);
      if (newBookmarks.has(recipeId)) {
        newBookmarks.delete(recipeId);
      } else {
        newBookmarks.add(recipeId);
      }
      setUserBookmarks(newBookmarks);
      sessionStorage.setItem('userBookmarks', JSON.stringify([...newBookmarks]));
    } catch (error) {
      console.error('Error toggling bookmark:', error);
    }
  };

  const handleCompareToggle = (recipeId) => {
    try {
      const newSelection = [...selectedForComparison];
      const index = newSelection.indexOf(recipeId);
      
      if (index > -1) {
        newSelection.splice(index, 1);
      } else if (newSelection.length < 3) {
        newSelection.push(recipeId);
      }
      
      setSelectedForComparison(newSelection);
    } catch (error) {
      console.error('Error handling comparison toggle:', error);
    }
  };

  const handleFilterChange = (filterType, value) => {
    try {
      setActiveFilters(prev => ({
        ...prev,
        [filterType]: value
      }));
    } catch (error) {
      console.error('Error changing filter:', error);
    }
  };

  // Enhanced grid classes for different view modes
  const getGridClasses = () => {
    if (kitchenMode) {
      return "grid grid-cols-1 md:grid-cols-2 gap-12"; // Kitchen mode - larger cards
    }
    
    switch (viewMode) {
      case 'list':
        return "space-y-4";
      case 'compact':
        return "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4";
      default:
        return "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8";
    }
  };

  return (
    <section id="recipes" className={`py-20 ${kitchenMode ? 'bg-gray-900' : 'bg-gradient-to-br from-gray-50 to-white'}`}>
      <div className="container mx-auto px-4">
        {/* EXISTING HEADER - Enhanced with new features */}
        <div className="text-center mb-16">
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold mb-4 ${
            kitchenMode 
              ? 'bg-orange-200 text-orange-800' 
              : 'bg-orange-100 text-orange-600'
          }`}>
            <Award className="w-4 h-4" />
            {kitchenMode ? 'Kitchen Mode Active' : 'Editor\'s Choice'}
          </div>
          <h2 className={`text-4xl md:text-5xl font-bold mb-4 ${
            kitchenMode ? 'text-white' : 'text-gray-900'
          }`}>
            Featured Festival Recipes
          </h2>
          <p className={`text-xl max-w-2xl mx-auto ${
            kitchenMode ? 'text-gray-200' : 'text-gray-600'
          }`}>
            Handpicked seasonal delights perfect for your celebrations
          </p>
        </div>

        {/* NEW ENHANCED CONTROLS - Only show if enhanced features are enabled */}
        {(enhancedFeatures.smartSearch || enhancedFeatures.personalization) && !kitchenMode && (
          <div className="mb-8 space-y-4">
            {/* View Mode and Sorting Controls */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white rounded-lg p-4 shadow-sm">
              <div className="flex items-center gap-4">
                
                {/* Sort Options */}
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-gray-700">Sort by:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="rating">Rating</option>
                    <option value="time">Cook Time</option>
                    <option value="difficulty">Difficulty</option>
                    <option value="cost">Cost</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-600">
                  {sortedAndFilteredRecipes.length} recipes
                </span>
                {selectedForComparison.length > 0 && (
                  <button
                    onClick={() => setShowComparison(true)}
                    className="px-3 py-1 bg-blue-500 text-white rounded-md text-sm hover:bg-blue-600"
                  >
                    Compare ({selectedForComparison.length})
                  </button>
                )}
              </div>
            </div>

            {/* Smart Filter Panel */}
            {SmartFilterPanel && (
              <SmartFilterPanel
                activeFilters={activeFilters}
                onFilterChange={handleFilterChange}
                availableRecipes={featuredRecipes}
              />
            )}
          </div>
        )}

        {/* ENHANCED RECIPE GRID */}
        <div className={getGridClasses()}>
          {sortedAndFilteredRecipes.map((recipe) => (
            <div key={recipe.id} className="relative">
              {/* Enhanced Recipe Card or Original Card */}
              {enhancedFeatures.personalization && EnhancedRecipeCard ? (
                <EnhancedRecipeCard
                  recipe={recipe}
                  onView={() => handleRecipeClick(recipe.id)} // ✅ FIXED: Pass onView expected by EnhancedRecipeCard
                  onToggleFavorite={handleToggleFavorite}
                  onToggleBookmark={handleToggleBookmark}
                  onCompareToggle={handleCompareToggle}
                  isFavorite={userFavorites.has(recipe.id)}
                  isBookmarked={userBookmarks.has(recipe.id)}
                  isSelectedForComparison={selectedForComparison.includes(recipe.id)}
                  viewCount={recipeViews[recipe.id] || 0}
                  viewMode={viewMode}
                  kitchenMode={kitchenMode}
                />
              ) : (
                // ✅ FIXED: ORIGINAL RECIPE CARD with proper onClick handler
                <RecipeCard 
                  key={recipe.id} 
                  recipe={recipe} 
                  onClick={handleRecipeClick} // ✅ FIXED: Properly passing the click handler
                  enhanced={true}
                  variant="featured"
                />
              )}

              {/* NEW ENHANCEMENT OVERLAYS - Only if features enabled */}
              {enhancedFeatures.personalization && (
                <>
                  {/* Trending indicator */}
                  {(recipeViews[recipe.id] || 0) > 10 && (
                    <div className="absolute top-2 left-2 bg-gradient-to-r from-pink-500 to-red-500 text-white px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      Trending
                    </div>
                  )}
                  
                  {/* New badge for recently added recipes */}
                  {recipe.isNew && (
                    <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                      New
                    </div>
                  )}
                </>
              )}
            </div>
          ))}
        </div>

        {/* No Results Message */}
        {sortedAndFilteredRecipes.length === 0 && (
          <div className="text-center py-12">
            <div className={`text-6xl mb-4 ${kitchenMode ? 'text-gray-400' : 'text-gray-300'}`}>🍽️</div>
            <h3 className={`text-xl font-semibold mb-2 ${kitchenMode ? 'text-white' : 'text-gray-900'}`}>
              No recipes found
            </h3>
            <p className={`${kitchenMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Try adjusting your filters or search terms
            </p>
          </div>
        )}

        {/* DEBUGGING INFO - Remove in production */}
        {process.env.NODE_ENV === 'development' && (
          <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-xs">
            <strong>Debug Info:</strong><br/>
            onRecipeClick prop: {onRecipeClick ? '✅ Available' : '❌ Missing'}<br/>
            Recipes count: {sortedAndFilteredRecipes.length}<br/>
            First recipe ID: {sortedAndFilteredRecipes[0]?.id || 'No recipes'}<br/>
            Enhanced features: {JSON.stringify(enhancedFeatures)}
          </div>
        )}
      </div>
    </section>
  );
};

export default FeaturedRecipes;