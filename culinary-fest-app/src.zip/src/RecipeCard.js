import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Heart, Star, Crown, Clock, Users, Eye, ArrowRight, 
  Bookmark, Share2, Award, TrendingUp, Flame, Zap,
  ChefHat, Calendar, Play, ShoppingCart
} from 'lucide-react';
import { OptimizedImage, Button, Tooltip } from './ui';

const RecipeCard = ({ recipe, onClick, enhanced = true, variant = 'default' }) => {
  // Core state with proper initialization
  const [isHovered, setIsHovered] = useState(false);
  const [loved, setLoved] = useState(false);
  const [bookmarked, setBookmarked] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // Enhanced state with fallbacks
  const [viewCount, setViewCount] = useState(() => recipe?.views || Math.floor(Math.random() * 1000) + 100);
  const [socialStats, setSocialStats] = useState(() => ({
    likes: recipe?.likes || Math.floor(Math.random() * 500) + 50,
    shares: recipe?.shares || Math.floor(Math.random() * 100) + 10,
    saves: recipe?.saves || Math.floor(Math.random() * 200) + 20
  }));
  const [personalizedScore, setPersonalizedScore] = useState(null);
  
  // Refs for cleanup
  const observerRef = useRef(null);
  const cardRef = useRef(null);

  // Enhanced personalization with error handling
  const calculatePersonalizedScore = useCallback(() => {
    try {
      const userPreferences = {
        skillLevel: 'intermediate',
        dietaryRestrictions: ['vegetarian'],
        favoritesCuisines: ['indian', 'italian'],
        cookingTime: 'quick'
      };

      let score = 0;
      
      // Safe property access with fallbacks
      if (recipe?.difficulty) {
        if (recipe.difficulty === 'Easy' && userPreferences.skillLevel === 'beginner') score += 30;
        if (recipe.difficulty === 'Medium' && userPreferences.skillLevel === 'intermediate') score += 30;
        if (recipe.difficulty === 'Hard' && userPreferences.skillLevel === 'advanced') score += 30;
      }
      
      if (recipe?.tags && Array.isArray(recipe.tags)) {
        if (recipe.tags.some(tag => 
          userPreferences.dietaryRestrictions.includes(tag.toLowerCase())
        )) score += 25;
      }
      
      if (userPreferences.cookingTime === 'quick' && recipe?.prepTime) {
        const prepTimeNum = parseInt(recipe.prepTime);
        if (!isNaN(prepTimeNum) && prepTimeNum <= 30) score += 20;
      }
      
      if (recipe?.rating && recipe.rating >= 4.5) score += 15;
      if (recipe?.trending) score += 10;
      
      setPersonalizedScore(Math.min(100, Math.max(0, score)));
    } catch (error) {
      console.error('Error calculating personalized score:', error);
      setPersonalizedScore(null);
    }
  }, [recipe]);

  // Enhanced view tracking with proper cleanup
  const initializeViewTracking = useCallback(() => {
    try {
      if (!cardRef.current) return;

      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
            // Debounced view count increment
            const timeoutId = setTimeout(() => {
              setViewCount(prev => prev + 1);
            }, 1000);
            
            // Cleanup timeout on unmount
            return () => clearTimeout(timeoutId);
          }
        },
        { 
          threshold: 0.5, 
          rootMargin: '0px'
        }
      );

      observer.observe(cardRef.current);
      observerRef.current = observer;

      return () => {
        if (observerRef.current) {
          observerRef.current.disconnect();
          observerRef.current = null;
        }
      };
    } catch (error) {
      console.error('Error setting up view tracking:', error);
    }
  }, []);

  // Enhanced interaction handlers with proper error handling and rollback
  const handleLoveClick = useCallback(async (e) => {
    e.stopPropagation();
    
    if (isLoading) return;
    
    try {
      setIsLoading(true);
      setError(null);
      
      const previousLoved = loved;
      const previousStats = socialStats;
      
      // Optimistic update
      setLoved(!previousLoved);
      setSocialStats(prev => ({
        ...prev,
        likes: prev.likes + (!previousLoved ? 1 : -1)
      }));

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Could add actual API call here
      // await api.toggleLike(recipe.id);
      
    } catch (error) {
      console.error('Error handling love click:', error);
      setError('Failed to update favorite status');
      
      // Rollback on error
      setLoved(loved);
      setSocialStats(socialStats);
    } finally {
      setIsLoading(false);
    }
  }, [loved, socialStats, isLoading]);

  const handleBookmarkClick = useCallback(async (e) => {
    e.stopPropagation();
    
    try {
      setError(null);
      const newBookmarked = !bookmarked;
      setBookmarked(newBookmarked);
      
      setSocialStats(prev => ({
        ...prev,
        saves: prev.saves + (newBookmarked ? 1 : -1)
      }));
      
      // Could add API call here
      // await api.toggleBookmark(recipe.id);
    } catch (error) {
      console.error('Error handling bookmark click:', error);
      setError('Failed to bookmark recipe');
    }
  }, [bookmarked]);

  const handleShareClick = useCallback(async (e) => {
    e.stopPropagation();
    
    try {
      setError(null);
      const shareData = {
        title: recipe.title,
        text: recipe.description,
        url: `${window.location.origin}/recipe/${recipe.id}`
      };

      if (navigator.share && /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.url);
        // Show success feedback (could implement toast notification)
        console.log('Recipe link copied to clipboard!');
      }
      
      setSocialStats(prev => ({
        ...prev,
        shares: prev.shares + 1
      }));
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Error handling share:', error);
        setError('Failed to share recipe');
      }
    }
  }, [recipe]);

  // ✅ FIXED: Recipe display handler - properly shows recipe details
  const handleCardClick = useCallback(() => {
    console.log('🔍 RecipeCard.js - Card clicked!');
    console.log('📋 RecipeCard.js - Recipe:', recipe);
    console.log('🔗 RecipeCard.js - Recipe ID:', recipe?.id);
    console.log('⚡ RecipeCard.js - onClick prop:', onClick);
    console.log('📍 RecipeCard.js - onClick type:', typeof onClick);
    
    try {
      if (onClick && recipe && recipe.id) {
        console.log('✅ RecipeCard.js - Calling parent onClick with ID:', recipe.id);
        // ✅ FIXED: Pass recipe.id to parent component
        onClick(recipe.id);
      } else {
        console.log('❌ RecipeCard.js - Using fallback alert - onClick missing or no recipe');
        console.log('🔧 RecipeCard.js - onClick available:', !!onClick);
        console.log('🔧 RecipeCard.js - recipe available:', !!recipe);
        console.log('🔧 RecipeCard.js - recipe.id available:', !!recipe?.id);
        
        // Enhanced fallback: Display recipe details in a modal-style alert
        const recipeDetails = `
🍽️ RECIPE DETAILS 🍽️
═══════════════════════════════════════════════════════════════

📝 ${recipe?.title || 'Unknown Recipe'}

📖 Description: 
${recipe?.description || 'No description available'}

⏰ Details:
• Prep Time: ${recipe?.prepTime || 'N/A'}
• Servings: ${recipe?.servings || 'N/A'} people
• Difficulty: ${recipe?.difficulty || 'N/A'}
• Rating: ${recipe?.rating || 'N/A'}/5 ⭐
• Chef: ${recipe?.chef || 'Unknown Chef'}

${recipe?.tags ? `🏷️ Tags: ${recipe.tags.join(', ')}` : ''}
${recipe?.calories ? `🔥 Calories: ${recipe.calories} per serving` : ''}
${recipe?.heatLevel ? `🌶️ Spice Level: ${recipe.heatLevel}/5` : ''}

${recipe?.ingredients ? `
📝 INGREDIENTS (${recipe.ingredients.length} items):
${recipe.ingredients.slice(0, 8).map((ing, i) => `${i + 1}. ${ing}`).join('\n')}${recipe.ingredients.length > 8 ? `\n...and ${recipe.ingredients.length - 8} more ingredients` : ''}
` : ''}

${recipe?.instructions ? `
👩‍🍳 COOKING STEPS:
${recipe.instructions.slice(0, 3).map((step, i) => `${i + 1}. ${step.slice(0, 100)}${step.length > 100 ? '...' : ''}`).join('\n\n')}${recipe.instructions.length > 3 ? `\n\n...and ${recipe.instructions.length - 3} more steps` : ''}
` : ''}

${recipe?.nutrition ? `
📊 NUTRITION (per serving):
• Protein: ${recipe.nutrition.protein || 'N/A'}
• Carbs: ${recipe.nutrition.carbs || 'N/A'}
• Fat: ${recipe.nutrition.fat || 'N/A'}
• Fiber: ${recipe.nutrition.fiber || 'N/A'}
` : ''}

═══════════════════════════════════════════════════════════════
        `;
        
        alert(recipeDetails);
      }
    } catch (error) {
      console.error('💥 RecipeCard.js - Error in handleCardClick:', error);
      setError('Failed to open recipe details');
    }
  }, [onClick, recipe]);

  const handleQuickAction = useCallback((action, e) => {
    e.stopPropagation();
    
    try {
      setError(null);
      console.log(`Quick action: ${action} for recipe ${recipe?.id}`);
      
      // Enhanced: Handle different quick actions
      switch (action) {
        case 'meal-plan':
          // Add to meal plan logic
          console.log('Added to meal plan');
          break;
        case 'shopping':
          // Add to shopping list logic
          console.log('Added to shopping list');
          break;
        case 'quick-cook':
          // Quick cook mode logic
          console.log('Quick cook mode activated');
          break;
        default:
          console.log('Unknown action:', action);
      }
    } catch (error) {
      console.error('Error handling quick action:', error);
      setError(`Failed to ${action.replace('-', ' ')}`);
    }
  }, [recipe?.id]);

  // Enhanced mouse handlers with debouncing
  const handleMouseEnter = useCallback(() => {
    setIsHovered(true);
  }, []);

  const handleMouseLeave = useCallback(() => {
    setIsHovered(false);
  }, []);

  // Enhanced difficulty styling with error handling
  const getDifficultyClasses = useCallback(() => {
    const baseClasses = 'px-3 py-1 rounded-full text-xs font-semibold transition-all duration-300 backdrop-blur-sm shadow-lg ';
    
    try {
      switch (recipe?.difficulty) {
        case 'Hard':
          return baseClasses + 'bg-red-500/90 text-white shadow-red-500/25';
        case 'Medium':
          return baseClasses + 'bg-amber-500/90 text-white shadow-amber-500/25';
        case 'Easy':
          return baseClasses + 'bg-green-500/90 text-white shadow-green-500/25';
        default:
          return baseClasses + 'bg-gray-500/90 text-white shadow-gray-500/25';
      }
    } catch (error) {
      console.error('Error getting difficulty classes:', error);
      return baseClasses + 'bg-gray-500/90 text-white';
    }
  }, [recipe?.difficulty]);

  // Enhanced card variants with better styling
  const getCardClasses = useCallback(() => {
    let baseClasses = `
      bg-white rounded-2xl shadow-lg hover:shadow-2xl 
      transition-all duration-500 overflow-hidden group cursor-pointer
      relative
    `;
    
    try {
      // Variant-specific classes
      switch (variant) {
        case 'compact':
          baseClasses += ' transform hover:-translate-y-1 hover:scale-[1.02] ';
          break;
        case 'featured':
          baseClasses += ' transform hover:-translate-y-3 ring-2 ring-orange-200 hover:ring-orange-300 ';
          break;
        default:
          baseClasses += ' transform hover:-translate-y-2 hover:scale-[1.01] ';
      }

      // Personalization enhancement
      if (personalizedScore && personalizedScore > 80) {
        baseClasses += ' ring-2 ring-blue-300 hover:ring-blue-400 ';
      }

      // Error state styling
      if (error) {
        baseClasses += ' ring-2 ring-red-200 ';
      }
      
    } catch (error) {
      console.error('Error getting card classes:', error);
    }

    return baseClasses;
  }, [variant, personalizedScore, error]);

  // Enhanced render methods with null checks
  const renderHeatLevel = useCallback((level) => {
    if (typeof level !== 'number' || level < 0) return null;
    
    try {
      return (
        <div className="bg-red-500/90 backdrop-blur-sm rounded-full px-2 py-1 flex items-center gap-1 shadow-lg">
          {[...Array(Math.min(5, level))].map((_, i) => (
            <Flame key={i} className="w-2 h-2 text-white fill-white" />
          ))}
        </div>
      );
    } catch (error) {
      console.error('Error rendering heat level:', error);
      return null;
    }
  }, []);

  const renderTags = useCallback(() => {
    if (!recipe?.tags || !Array.isArray(recipe.tags)) return null;
    
    try {
      return (
        <div className="flex flex-wrap gap-2 mb-3">
          {recipe.tags.slice(0, 2).map((tag) => (
            <div
              key={tag}
              className="px-2 py-1 bg-gradient-to-r from-amber-50 to-orange-50 text-orange-700 rounded-lg text-xs font-medium border border-orange-200 hover:from-amber-100 hover:to-orange-100 transition-colors cursor-pointer"
            >
              {tag}
            </div>
          ))}
          {recipe.tags.length > 2 && (
            <div className="px-2 py-1 bg-gradient-to-r from-amber-50 to-orange-50 text-orange-700 rounded-lg text-xs font-medium border border-orange-200">
              +{recipe.tags.length - 2}
            </div>
          )}
        </div>
      );
    } catch (error) {
      console.error('Error rendering tags:', error);
      return null;
    }
  }, [recipe?.tags]);

  // Enhanced initialization with proper cleanup
  useEffect(() => {
    if (!recipe) return;
    
    calculatePersonalizedScore();
    const cleanup = initializeViewTracking();
    
    return cleanup;
  }, [recipe, calculatePersonalizedScore, initializeViewTracking]);

  // Early return with proper error boundary - MOVED AFTER ALL HOOKS
  if (!recipe) {
    console.error('RecipeCard: recipe prop is required');
    return (
      <div className="bg-gray-100 rounded-2xl p-6 text-center">
        <div className="text-gray-500">Recipe data not available</div>
      </div>
    );
  }

  return (
    <div
      ref={cardRef}
      className={getCardClasses()}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={handleCardClick}
      data-recipe-id={recipe.id}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleCardClick();
        }
      }}
      aria-label={`View recipe for ${recipe.title}`}
    >
      {/* Error banner */}
      {error && (
        <div className="absolute top-0 left-0 right-0 bg-red-500 text-white text-xs px-3 py-1 z-50">
          {error}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setError(null);
            }}
            className="ml-2 hover:text-red-200"
            aria-label="Dismiss error"
          >
            ×
          </button>
        </div>
      )}

      <div className="relative h-64 overflow-hidden">
        <OptimizedImage
          src={recipe.image}
          alt={recipe.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          priority={variant === 'featured'}
        />
        
        {/* Fixed gradient overlay - no interference with buttons */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
        
        {/* ✅ FIXED: Action buttons - always visible and clickable with proper z-index */}
        <div className="absolute top-4 right-4 flex flex-col gap-2 z-30">
          <Tooltip content={loved ? "Remove from favorites" : "Add to favorites"}>
            <button
              onClick={handleLoveClick}
              disabled={isLoading}
              className="w-10 h-10 bg-white/95 backdrop-blur-sm rounded-full flex items-center justify-center transition-all duration-300 hover:bg-white hover:scale-110 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
              aria-label={loved ? "Remove from favorites" : "Add to favorites"}
            >
              <Heart className={`w-5 h-5 transition-all ${
                loved ? "fill-red-500 text-red-500 scale-110" : "text-gray-600 hover:text-red-500"
              } ${isLoading ? 'animate-pulse' : ''}`} />
            </button>
          </Tooltip>
          
          <Tooltip content={bookmarked ? "Remove from saved" : "Save recipe"}>
            <button
              onClick={handleBookmarkClick}
              className="w-10 h-10 bg-white/95 backdrop-blur-sm rounded-full flex items-center justify-center transition-all duration-300 hover:bg-white hover:scale-110 shadow-lg hover:shadow-xl"
              aria-label={bookmarked ? "Remove from saved" : "Save recipe"}
            >
              <Bookmark className={bookmarked ? "w-5 h-5 fill-blue-500 text-blue-500" : "w-5 h-5 text-gray-600 hover:text-blue-500"} />
            </button>
          </Tooltip>
          
          <Tooltip content="Share recipe">
            <button
              onClick={handleShareClick}
              className="w-10 h-10 bg-white/95 backdrop-blur-sm rounded-full flex items-center justify-center transition-all duration-300 hover:bg-white hover:scale-110 shadow-lg hover:shadow-xl"
              aria-label="Share recipe"
            >
              <Share2 className="w-5 h-5 text-gray-600 hover:text-blue-500" />
            </button>
          </Tooltip>
        </div>
        
        {/* Enhanced badges with better positioning */}
        <div className="absolute top-4 left-4 flex flex-col gap-2 z-10">
          {recipe.premium && (
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 shadow-lg backdrop-blur-sm">
              <Crown className="w-3 h-3" />
              Premium
            </div>
          )}

          {recipe.trending && (
            <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 shadow-lg animate-pulse backdrop-blur-sm">
              <TrendingUp className="w-3 h-3" />
              Trending
            </div>
          )}

          {enhanced && personalizedScore && personalizedScore > 80 && (
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 shadow-lg backdrop-blur-sm">
              <Award className="w-3 h-3" />
              Perfect Match
            </div>
          )}

          {recipe.isNew && (
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 shadow-lg backdrop-blur-sm">
              <Zap className="w-3 h-3" />
              New
            </div>
          )}
        </div>

        {/* Enhanced bottom overlay */}
        <div className="absolute bottom-4 left-4 right-4 z-10">
          <div className="flex items-center justify-between mb-2">
            <div className={getDifficultyClasses()}>
              {recipe.difficulty || 'Unknown'}
            </div>
            <div className="flex items-center gap-2">
              <div className="bg-white/95 backdrop-blur-sm rounded-full px-3 py-1 flex items-center gap-1 shadow-lg">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="text-sm font-semibold">{recipe.rating || 'N/A'}</span>
              </div>
              {enhanced && recipe.heatLevel > 0 && renderHeatLevel(recipe.heatLevel)}
            </div>
          </div>

          {/* Enhanced: Quick stats */}
          {enhanced && (
            <div className="flex items-center justify-between text-white/80 text-xs">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {viewCount.toLocaleString()}
                </span>
                <span className="flex items-center gap-1">
                  <Heart className="w-3 h-3" />
                  {socialStats.likes.toLocaleString()}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>{recipe.publishedDate || '2 days ago'}</span>
              </div>
            </div>
          )}
        </div>

        {/* ✅ FIXED: Enhanced hover overlay with functional quick actions */}
        {isHovered && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-sm z-20">
            <div className="flex gap-3">
              <Button 
                variant="primary" 
                className="transform scale-110 shadow-2xl group/preview"
                onClick={(e) => {
                  e.stopPropagation();
                  handleCardClick(); // ✅ FIXED: This now properly handles the click
                }}
              >
                <Eye className="w-4 h-4 mr-2" />
                Quick Preview
              </Button>
              
              {enhanced && (
                <>
                  <Tooltip content="Add to meal plan">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={(e) => handleQuickAction('meal-plan', e)}
                      className="bg-white/95 hover:bg-white transform scale-110 shadow-2xl"
                    >
                      <Calendar className="w-4 h-4" />
                    </Button>
                  </Tooltip>
                  
                  <Tooltip content="Add to shopping list">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={(e) => handleQuickAction('shopping', e)}
                      className="bg-white/95 hover:bg-white transform scale-110 shadow-2xl"
                    >
                      <ShoppingCart className="w-4 h-4" />
                    </Button>
                  </Tooltip>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Enhanced card content */}
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-orange-600 transition-colors">
          {recipe.title}
        </h3>

        {renderTags()}

        <p className="text-gray-600 mb-4 text-sm leading-relaxed line-clamp-2">
          {recipe.description || 'No description available'}
        </p>

        {/* Enhanced stats with better icons and layout */}
        <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4 text-orange-500" />
            <span>{recipe.prepTime || 'N/A'}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4 text-blue-500" />
            <span>{recipe.servings || 'N/A'}</span>
          </div>
          <div className="flex items-center gap-1">
            <Flame className="w-4 h-4 text-red-500" />
            <span className="text-xs">{recipe.calories || 0} cal</span>
          </div>
          {enhanced && recipe.cookTime && (
            <div className="flex items-center gap-1">
              <ChefHat className="w-4 h-4 text-purple-500" />
              <span className="text-xs">{recipe.cookTime}</span>
            </div>
          )}
        </div>

        {/* Enhanced chef info */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-white text-xs font-semibold">
                {recipe.chef ? recipe.chef.split(' ').map(n => n[0]).join('').slice(0, 2) : '??'}
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-sm text-gray-600 truncate block">by {recipe.chef || 'Unknown Chef'}</span>
              {enhanced && recipe.chefRating && (
                <div className="flex items-center gap-1">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span className="text-xs text-gray-500">{recipe.chefRating}</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-3 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Heart className="w-3 h-3" />
              <span>{socialStats.likes.toLocaleString()}</span>
            </div>
            {enhanced && (
              <div className="flex items-center gap-1">
                <Bookmark className="w-3 h-3" />
                <span>{socialStats.saves.toLocaleString()}</span>
              </div>
            )}
          </div>
        </div>

        {/* Enhanced: Personalization bar */}
        {enhanced && personalizedScore && (
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
              <span>Match Score</span>
              <span>{personalizedScore}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
              <div 
                className={`h-2 rounded-full transition-all duration-1000 ease-out ${
                  personalizedScore > 80 ? 'bg-gradient-to-r from-blue-500 to-green-500' :
                  personalizedScore > 60 ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                  'bg-gradient-to-r from-gray-400 to-gray-500'
                }`}
                style={{ width: `${personalizedScore}%` }}
              />
            </div>
          </div>
        )}

        {/* ✅ FIXED: Enhanced action button with proper click handler */}
        <div className="flex gap-2">
          <Button 
            className="flex-1 group bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 py-3 text-base font-semibold"
            onClick={(e) => {
              e.stopPropagation();
              handleCardClick(); // ✅ FIXED: This now properly calls the parent onClick handler
            }}
          >
            View Full Recipe
            <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
          </Button>
          
          {enhanced && (
            <Tooltip content="Quick cook mode">
              <Button
                variant="outline"
                size="icon"
                onClick={(e) => handleQuickAction('quick-cook', e)}
                className="flex-shrink-0 group/cook hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300"
              >
                <Play className="w-4 h-4 transition-transform group-hover/cook:scale-110" />
              </Button>
            </Tooltip>
          )}
        </div>

        {/* Enhanced: Quick nutrition info */}
        {enhanced && recipe.nutrition && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="text-xs">
                <div className="font-semibold text-orange-600">{recipe.nutrition.protein || 'N/A'}</div>
                <div className="text-gray-500">Protein</div>
              </div>
              <div className="text-xs">
                <div className="font-semibold text-blue-600">{recipe.nutrition.carbs || 'N/A'}</div>
                <div className="text-gray-500">Carbs</div>
              </div>
              <div className="text-xs">
                <div className="font-semibold text-green-600">{recipe.nutrition.fat || 'N/A'}</div>
                <div className="text-gray-500">Fat</div>
              </div>
            </div>
          </div>
        )}

        {/* DEBUGGING INFO - Remove in production */}
        {process.env.NODE_ENV === 'development' && (
          <div className="mt-4 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
            <strong>Debug:</strong><br/>
            onClick prop: {onClick ? '✅' : '❌'}<br/>
            Recipe ID: {recipe?.id || 'Missing'}<br/>
            Recipe title: {recipe?.title || 'Missing'}
          </div>
        )}
      </div>
    </div>
  );
};

export default RecipeCard;