import React, { useState, useEffect } from 'react';
import Header from './Header';
import HeroSection from './HeroSection';
import SouthIndianBreakfast from './SouthIndianBreakfast';
import FeaturedRecipes from './FeaturedRecipes';
import NewsletterModal from './NewsletterModal';
import RecipeModal from './RecipeModal';
import IndianCuisineApp from './IndianCuisineApp';
import Footer from './Footer';

// NEW ENHANCEMENT LAYERS - Additive only, no existing code modification
import { SmartRecommendationEngine,EnhancedSearchBar,PersonalizationDashboard,KitchenModeOverlay,OfflineManager,ErrorBoundaryWrapper } from './enhanced.js';

const CulinaryFest = () => {
  // EXISTING STATE - Preserved exactly as is
  const [showNewsletter, setShowNewsletter] = useState(false);
  const [selectedRecipeId, setSelectedRecipeId] = useState(null);
  const [showRecipeModal, setShowRecipeModal] = useState(false);
  const [currentView, setCurrentView] = useState('home'); // 'home' or 'indian'

  // NEW ENHANCEMENT STATE - Additive layer, doesn't interfere with existing
  const [enhancedFeatures, setEnhancedFeatures] = useState({
    smartSearch: false,
    kitchenMode: false,
    personalization: false,
    offlineMode: false,
    aiRecommendations: false
  });
  const [userPreferences, setUserPreferences] = useState(null);
  const [searchFilters, setSearchFilters] = useState({});
  const [kitchenModeActive, setKitchenModeActive] = useState(false);

  // EXISTING useEffect - Preserved exactly as is
  useEffect(() => {
    try {
      const hasVisited = sessionStorage.getItem('hasVisited');
      if (!hasVisited) {
        const timer = setTimeout(() => {
          setShowNewsletter(true);
          sessionStorage.setItem('hasVisited', 'true');
        }, 3000);
        return () => clearTimeout(timer);
      }
    } catch (error) {
      console.error('Error accessing sessionStorage:', error);
    }
  }, []);

  // NEW ENHANCEMENT useEffect - Load user preferences and enhanced features
  useEffect(() => {
    try {
      // Load enhanced features preferences (new functionality)
      const savedFeatures = sessionStorage.getItem('enhancedFeatures');
      if (savedFeatures) {
        setEnhancedFeatures(JSON.parse(savedFeatures));
      }

      // Load user preferences for AI recommendations (new functionality)
      const savedPreferences = sessionStorage.getItem('userPreferences');
      if (savedPreferences) {
        setUserPreferences(JSON.parse(savedPreferences));
      }
    } catch (error) {
      console.error('Error loading enhanced features:', error);
      // Graceful fallback - continue with basic functionality
    }
  }, []);

  // EXISTING HANDLERS - Preserved exactly as is
  const handleRecipeClick = (recipeId) => {
    try {
      setSelectedRecipeId(recipeId);
      setShowRecipeModal(true);
    } catch (error) {
      console.error('Error handling recipe click:', error);
    }
  };

  const handleShowNewsletter = () => {
    try {
      setShowNewsletter(true);
    } catch (error) {
      console.error('Error showing newsletter:', error);
    }
  };

  const handleCloseNewsletter = () => {
    try {
      setShowNewsletter(false);
    } catch (error) {
      console.error('Error closing newsletter:', error);
    }
  };

  const handleCloseRecipeModal = () => {
    try {
      setShowRecipeModal(false);
    } catch (error) {
      console.error('Error closing recipe modal:', error);
    }
  };

  const handleNavigateToIndian = () => {
    try {
      setCurrentView('indian');
    } catch (error) {
      console.error('Error navigating to Indian cuisine:', error);
    }
  };

  const handleNavigateToHome = () => {
    try {
      setCurrentView('home');
    } catch (error) {
      console.error('Error navigating to home:', error);
    }
  };

  // NEW ENHANCED HANDLERS - Additive functionality
  const handleToggleEnhancedFeature = (featureName) => {
    try {
      const newFeatures = {
        ...enhancedFeatures,
        [featureName]: !enhancedFeatures[featureName]
      };
      setEnhancedFeatures(newFeatures);
      sessionStorage.setItem('enhancedFeatures', JSON.stringify(newFeatures));
    } catch (error) {
      console.error('Error toggling enhanced feature:', error);
    }
  };

  const handleSearchWithFilters = (query, filters) => {
    try {
      setSearchFilters({ query, ...filters });
      // Enhanced search logic here
    } catch (error) {
      console.error('Error in enhanced search:', error);
      // Fallback to basic search
    }
  };

  const handleEnterKitchenMode = () => {
    try {
      setKitchenModeActive(true);
      // Enable kitchen-friendly UI
      if ('wakeLock' in navigator) {
        navigator.wakeLock.request('screen').catch(console.error);
      }
    } catch (error) {
      console.error('Error entering kitchen mode:', error);
    }
  };

  const handleExitKitchenMode = () => {
    try {
      setKitchenModeActive(false);
    } catch (error) {
      console.error('Error exiting kitchen mode:', error);
    }
  };

  const handleUpdatePreferences = (preferences) => {
    try {
      setUserPreferences(preferences);
      sessionStorage.setItem('userPreferences', JSON.stringify(preferences));
    } catch (error) {
      console.error('Error updating preferences:', error);
    }
  };

  return (
    <ErrorBoundaryWrapper>
      <div className="min-h-screen font-sans bg-gray-50">
        {/* ENHANCED FEATURES OVERLAY - Only renders if features are enabled */}
        {enhancedFeatures.offlineMode && <OfflineManager />}
        
        {kitchenModeActive && (
          <KitchenModeOverlay
            selectedRecipeId={selectedRecipeId}
            onExit={handleExitKitchenMode}
          />
        )}

        {currentView === 'home' ? (
          <>
            {/* EXISTING COMPONENTS - Preserved exactly as is */}
            <Header 
              onShowNewsletter={handleShowNewsletter} 
              onNavigateToIndian={handleNavigateToIndian}
              // NEW PROPS - Enhanced features (backward compatible)
              enhancedFeatures={enhancedFeatures}
              onToggleFeature={handleToggleEnhancedFeature}
              onEnterKitchenMode={handleEnterKitchenMode}
            />
            
            <main>
              {/* ENHANCED SEARCH BAR - Additive layer */}
              {enhancedFeatures.smartSearch && (
                <div className="container mx-auto px-4 -mt-8 relative z-10">
                  <EnhancedSearchBar 
                    onSearch={handleSearchWithFilters}
                    userPreferences={userPreferences}
                  />
                </div>
              )}

              {/* AI RECOMMENDATIONS - Additive layer */}
              {enhancedFeatures.aiRecommendations && userPreferences && (
                <SmartRecommendationEngine
                  preferences={userPreferences}
                  onRecipeClick={handleRecipeClick}
                />
              )}

              {/* EXISTING SECTIONS - Preserved exactly as is */}
              <HeroSection onShowNewsletter={handleShowNewsletter} />
              
              <SouthIndianBreakfast 
                onRecipeClick={handleRecipeClick}
                // NEW PROPS - Enhanced features (backward compatible)
                kitchenMode={kitchenModeActive}
                searchFilters={searchFilters}
              />
              
              <FeaturedRecipes 
                onRecipeClick={handleRecipeClick}
                // NEW PROPS - Enhanced features (backward compatible)
                kitchenMode={kitchenModeActive}
                searchFilters={searchFilters}
              />

              {/* PERSONALIZATION DASHBOARD - Additive layer */}
              {enhancedFeatures.personalization && (
                <PersonalizationDashboard
                  preferences={userPreferences}
                  onUpdatePreferences={handleUpdatePreferences}
                  onRecipeClick={handleRecipeClick}
                />
              )}
            </main>
            
            {/* EXISTING FOOTER - Preserved exactly as is */}
            <Footer />
          </>
        ) : (
          // EXISTING INDIAN CUISINE APP - Preserved exactly as is
          <IndianCuisineApp 
            onNavigateToHome={handleNavigateToHome}
            // NEW PROPS - Enhanced features (backward compatible)
            enhancedFeatures={enhancedFeatures}
            kitchenMode={kitchenModeActive}
          />
        )}
        
        {/* EXISTING MODALS - Preserved exactly as is */}
        <NewsletterModal 
          isOpen={showNewsletter}
          onClose={handleCloseNewsletter}
        />
        
        <RecipeModal 
          selectedRecipeId={selectedRecipeId}
          isOpen={showRecipeModal}
          onClose={handleCloseRecipeModal}
          // NEW PROPS - Enhanced features (backward compatible)
          enhancedFeatures={enhancedFeatures}
          kitchenMode={kitchenModeActive}
          userPreferences={userPreferences}
        />

        {/* ENHANCED FEATURES TOGGLE PANEL - Additive layer */}
        <div className="fixed bottom-4 right-4 z-50">
          <div className="bg-white rounded-lg shadow-lg p-4 border">
            <h4 className="font-semibold mb-2 text-sm">Enhanced Features</h4>
            <div className="space-y-2 text-xs">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={enhancedFeatures.smartSearch}
                  onChange={() => handleToggleEnhancedFeature('smartSearch')}
                  className="rounded"
                />
                Smart Search
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={enhancedFeatures.aiRecommendations}
                  onChange={() => handleToggleEnhancedFeature('aiRecommendations')}
                  className="rounded"
                />
                AI Recommendations
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={enhancedFeatures.personalization}
                  onChange={() => handleToggleEnhancedFeature('personalization')}
                  className="rounded"
                />
                Personalization
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={enhancedFeatures.offlineMode}
                  onChange={() => handleToggleEnhancedFeature('offlineMode')}
                  className="rounded"
                />
                Offline Mode
              </label>
            </div>
          </div>
        </div>
      </div>
    </ErrorBoundaryWrapper>
  );
};

export default CulinaryFest;