
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Search, Mic, MicOff, Camera, Filter, Grid, List, Eye, Heart, Bookmark,
  Clock, Users, Star, Trophy, Calendar, ShoppingCart, Play, Pause,
  Volume2, VolumeX, Download, Wifi, WifiOff, Settings, User, Bell,
  ChefHat, Zap, TrendingUp, Share2, MessageCircle, Award,
  // New icons for missing components
  BarChart3, Globe, Mail, RefreshCw, ThumbsUp, Image, CheckCircle,
  Facebook, Twitter, Instagram, Copy, Layers, RotateCcw, Languages,
  X, Send, Loader, AlertCircle, Plus, Minus, ArrowUp, ArrowDown
} from 'lucide-react';

// 6. SocialMediaLinks - Dynamic social sharing
export const SocialMediaLinks = ({ shareUrl = window.location.href, title = 'Check out this recipe!', description = 'Amazing recipe I found', image }) => {
  const [shareCount, setShareCount] = useState({});
  const [sharing, setSharing] = useState(false);
  const [copied, setCopied] = useState(false);

  const socialPlatforms = [
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-blue-600 hover:bg-blue-700',
      shareUrl: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(title)}`,
      customMessage: `${title} - ${description}`
    },
    {
      name: 'Twitter', 
      icon: Twitter,
      color: 'bg-sky-500 hover:bg-sky-600',
      shareUrl: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(`${title} - ${description}`)}`,
      customMessage: `${title} 🍳 ${description} #recipe #cooking`
    },
    {
      name: 'Pinterest',
      icon: Image,
      color: 'bg-red-600 hover:bg-red-700', 
      shareUrl: `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(shareUrl)}&description=${encodeURIComponent(title)}&media=${encodeURIComponent(image || '')}`,
      customMessage: title
    },
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-green-500 hover:bg-green-600',
      shareUrl: `https://wa.me/?text=${encodeURIComponent(`${title} - ${shareUrl}`)}`,
      customMessage: `Check out this recipe: ${title}\n${shareUrl}`
    }
  ];

  const handleShare = async (platform) => {
    setSharing(true);
    
    try {
      // Try native share API first (mobile)
      if (navigator.share && platform.name === 'Native') {
        await navigator.share({
          title,
          text: description,
          url: shareUrl
        });
        return;
      }

      // Open social platform share dialog
      const width = 600;
      const height = 400;
      const left = (window.screen.width - width) / 2;
      const top = (window.screen.height - height) / 2;
      
      window.open(
        platform.shareUrl,
        'share',
        `width=${width},height=${height},left=${left},top=${top},scrollbars=yes,resizable=yes`
      );

      // Track share analytics (mock)
      console.log(`Shared via ${platform.name}:`, { title, url: shareUrl });
      
    } catch (error) {
      console.error('Share failed:', error);
    } finally {
      setSharing(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = shareUrl;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <ErrorBoundaryWrapper>
      <div className="bg-white rounded-lg p-4">
        <h4 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
          <Share2 className="w-4 h-4" />
          Share this recipe
        </h4>
        
        <div className="flex flex-wrap gap-2 mb-3">
          {socialPlatforms.map(platform => {
            const Icon = platform.icon;
            return (
              <button
                key={platform.name}
                onClick={() => handleShare(platform)}
                disabled={sharing}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-white text-sm font-medium transition-colors ${platform.color} disabled:opacity-50 disabled:cursor-not-allowed`}
                title={`Share on ${platform.name}`}
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{platform.name}</span>
              </button>
            );
          })}

          {/* Native Share (Mobile) */}
          {navigator.share && (
            <button
              onClick={() => handleShare({ name: 'Native' })}
              className="flex items-center gap-2 px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg text-sm font-medium transition-colors"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">Share</span>
            </button>
          )}
        </div>

        {/* Copy Link */}
        <div className="flex items-center gap-2 pt-3 border-t border-gray-200">
          <input
            type="text"
            value={shareUrl}
            readOnly
            className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded text-sm text-gray-600"
          />
          <button
            onClick={copyToClipboard}
            className={`px-3 py-2 rounded text-sm font-medium transition-colors flex items-center gap-1 ${
              copied 
                ? 'bg-green-100 text-green-800' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {copied ? (
              <>
                <CheckCircle className="w-4 h-4" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Copy
              </>
            )}
          </button>
        </div>

        {/* Share Stats (if available) */}
        {Object.keys(shareCount).length > 0 && (
          <div className="mt-3 pt-3 border-t border-gray-200">
            <div className="flex items-center justify-between text-xs text-gray-500">
              <span>Share Stats:</span>
              <div className="flex gap-3">
                {Object.entries(shareCount).map(([platform, count]) => (
                  <span key={platform}>{platform}: {count}</span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundaryWrapper>
  );
};

// 7. NewsletterPreferences - Subscription management
export const NewsletterPreferences = ({ currentPreferences = {}, onUpdate }) => {
  const [preferences, setPreferences] = useState({
    email: '',
    frequency: 'weekly',
    topics: [],
    formats: ['html'],
    ...currentPreferences
  });
  const [saving, setSaving] = useState(false);
  const [emailValid, setEmailValid] = useState(true);
  const [subscribed, setSubscribed] = useState(!!currentPreferences.email);

  const frequencyOptions = [
    { value: 'daily', label: 'Daily', description: 'Get fresh recipes every day' },
    { value: 'weekly', label: 'Weekly', description: 'Weekly recipe roundup' },
    { value: 'monthly', label: 'Monthly', description: 'Monthly featured recipes' }
  ];

  const topicOptions = [
    { value: 'quick-meals', label: 'Quick Meals', icon: '⚡' },
    { value: 'healthy', label: 'Healthy Recipes', icon: '🥗' },
    { value: 'desserts', label: 'Desserts', icon: '🍰' },
    { value: 'international', label: 'International Cuisine', icon: '🌍' },
    { value: 'vegetarian', label: 'Vegetarian/Vegan', icon: '🌱' },
    { value: 'seasonal', label: 'Seasonal Recipes', icon: '🍂' }
  ];

  const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleEmailChange = (email) => {
    setPreferences(prev => ({ ...prev, email }));
    setEmailValid(validateEmail(email) || email === '');
  };

  const handleTopicToggle = (topic) => {
    setPreferences(prev => ({
      ...prev,
      topics: prev.topics.includes(topic)
        ? prev.topics.filter(t => t !== topic)
        : [...prev.topics, topic]
    }));
  };

  const handleSave = async () => {
    if (!emailValid || !preferences.email) return;
    
    setSaving(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      onUpdate?.(preferences);
      setSubscribed(true);
      
      // Show success message
      console.log('Newsletter preferences saved:', preferences);
    } catch (error) {
      console.error('Error saving preferences:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleUnsubscribe = async () => {
    if (('Are you sure you want to unsubscribe from all newsletters?')) return;
    
    setSaving(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setSubscribed(false);
      setPreferences(prev => ({ ...prev, email: '' }));
      onUpdate?.({ ...preferences, email: '' });
    } catch (error) {
      console.error('Error unsubscribing:', error);
    } finally {
      setSaving(false);
    }
  };

  return (
    <ErrorBoundaryWrapper>
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Mail className="w-5 h-5 text-blue-500" />
            Newsletter Preferences
          </h3>
          {subscribed && (
            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-sm font-medium">
              Subscribed
            </span>
          )}
        </div>

        <div className="space-y-6">
          {/* Email Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={preferences.email}
              onChange={(e) => handleEmailChange(e.target.value)}
              placeholder="your.email@example.com"
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                !emailValid ? 'border-red-300 bg-red-50' : 'border-gray-300'
              }`}
            />
            {!emailValid && (
              <p className="mt-1 text-sm text-red-600">Please enter a valid email address</p>
            )}
          </div>

          {/* Frequency Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              How often would you like to receive emails?
            </label>
            <div className="space-y-3">
              {frequencyOptions.map(option => (
                <label key={option.value} className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="radio"
                    name="frequency"
                    value={option.value}
                    checked={preferences.frequency === option.value}
                    onChange={(e) => setPreferences(prev => ({ ...prev, frequency: e.target.value }))}
                    className="mt-1 text-blue-600 focus:ring-blue-500"
                  />
                  <div>
                    <div className="font-medium text-gray-900">{option.label}</div>
                    <div className="text-sm text-gray-600">{option.description}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Topic Preferences */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              What topics interest you?
            </label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {topicOptions.map(topic => (
                <label key={topic.value} className="flex items-center gap-3 p-3 border border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="checkbox"
                    checked={preferences.topics.includes(topic.value)}
                    onChange={() => handleTopicToggle(topic.value)}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xl">{topic.icon}</span>
                  <span className="text-sm font-medium text-gray-900">{topic.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Email Format */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Email Format
            </label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.formats.includes('html')}
                  onChange={(e) => {
                    const formats = e.target.checked 
                      ? [...preferences.formats.filter(f => f !== 'html'), 'html']
                      : preferences.formats.filter(f => f !== 'html');
                    setPreferences(prev => ({ ...prev, formats }));
                  }}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-900">Rich HTML (recommended)</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.formats.includes('text')}
                  onChange={(e) => {
                    const formats = e.target.checked 
                      ? [...preferences.formats.filter(f => f !== 'text'), 'text']
                      : preferences.formats.filter(f => f !== 'text');
                    setPreferences(prev => ({ ...prev, formats }));
                  }}
                  className="text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-900">Plain Text</span>
              </label>
            </div>
          </div>

          {/* GDPR Compliance */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h4 className="text-sm font-medium text-gray-900 mb-2">Privacy & Data</h4>
            <p className="text-xs text-gray-600 mb-3">
              We respect your privacy. Your email will only be used for our newsletter and you can unsubscribe at any time. 
              We never share your data with third parties.
            </p>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="privacy-consent"
                required
                className="text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="privacy-consent" className="text-xs text-gray-700">
                I agree to receive newsletters and understand the privacy policy
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleSave}
              disabled={saving || !emailValid || !preferences.email}
              className="flex-1 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
            >
              {saving ? (
                <>
                  <Loader className="w-4 h-4 animate-spin" />
                  Saving...
                </>
              ) : subscribed ? (
                'Update Preferences'
              ) : (
                'Subscribe'
              )}
            </button>
            
            {subscribed && (
              <button
                onClick={handleUnsubscribe}
                disabled={saving}
                className="px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Unsubscribe
              </button>
            )}
          </div>

          {/* Double Opt-in Notice */}
          {!subscribed && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                <strong>Double opt-in required:</strong> After subscribing, check your email for a confirmation link to complete the process.
              </p>
            </div>
          )}
        </div>
      </div>
    </ErrorBoundaryWrapper>
  );
};

// 8. CommunityStats - Real-time community metrics
export const CommunityStats = ({ refreshInterval = 300000 }) => {
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [error, setError] = useState(null);
  const intervalRef = useRef(null);

  const fetchCommunityStats = useCallback(async () => {
    try {
      setError(null);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock real-time community data
      const mockStats = {
        totalRecipes: 12847 + Math.floor(Math.random() * 100),
        activeUsers: 3456 + Math.floor(Math.random() * 50),
        recipesThisWeek: 234 + Math.floor(Math.random() * 20),
        totalRatings: 45678 + Math.floor(Math.random() * 200),
        topChefs: [
          { name: 'Chef Maria', recipes: 156, avatar: '👩‍🍳' },
          { name: 'Chef Kumar', recipes: 143, avatar: '👨‍🍳' },
          { name: 'Chef Sarah', recipes: 128, avatar: '👩‍🍳' }
        ],
        popularRecipes: [
          { title: 'Creamy Pasta Carbonara', views: 2341 },
          { title: 'Spicy Thai Curry', views: 1987 },
          { title: 'Chocolate Lava Cake', views: 1756 }
        ],
        weeklyGrowth: {
          recipes: 15.3,
          users: 8.7,
          ratings: 22.1
        }
      };

      setStats(mockStats);
      setLastUpdated(new Date());
      setLoading(false);
      
    } catch (err) {
      console.error('Error fetching community stats:', err);
      setError('Unable to load community stats');
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCommunityStats();
    
    // Set up auto-refresh
    if (refreshInterval > 0) {
      intervalRef.current = setInterval(fetchCommunityStats, refreshInterval);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [fetchCommunityStats, refreshInterval]);

  const formatNumber = (num) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const AnimatedCounter = ({ value, duration = 2000 }) => {
    const [displayValue, setDisplayValue] = useState(0);

    useEffect(() => {
      let startTime = Date.now();
      const startValue = displayValue;
      const endValue = value;

      const animate = () => {
        const now = Date.now();
        const elapsed = now - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentValue = Math.floor(startValue + (endValue - startValue) * easeOut);
        
        setDisplayValue(currentValue);
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      
      animate();
    }, [value, duration]);

    return <span>{formatNumber(displayValue)}</span>;
  };

  if (loading && !stats.totalRecipes) {
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded mb-4"></div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="bg-gray-100 h-20 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundaryWrapper fallback={
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center">
        <p className="text-yellow-800">Community stats temporarily unavailable</p>
        <button 
          onClick={fetchCommunityStats}
          className="mt-2 px-3 py-1 bg-yellow-100 text-yellow-700 rounded text-sm hover:bg-yellow-200"
        >
          Retry
        </button>
      </div>
    }>
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-500" />
            Community Stats
          </h3>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <button
              onClick={fetchCommunityStats}
              disabled={loading}
              className="p-1 hover:text-gray-700 transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            {lastUpdated && (
              <span>Updated {lastUpdated.toLocaleTimeString()}</span>
            )}
          </div>
        </div>

        {error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
            <p className="text-red-800">{error}</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Main Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">
                  <AnimatedCounter value={stats.totalRecipes || 0} />
                </div>
                <div className="text-sm text-blue-800">Total Recipes</div>
                {stats.weeklyGrowth?.recipes && (
                  <div className="flex items-center justify-center gap-1 mt-1 text-xs text-green-600">
                    <ArrowUp className="w-3 h-3" />
                    {stats.weeklyGrowth.recipes}%
                  </div>
                )}
              </div>

              <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  <AnimatedCounter value={stats.activeUsers || 0} />
                </div>
                <div className="text-sm text-green-800">Active Users</div>
                {stats.weeklyGrowth?.users && (
                  <div className="flex items-center justify-center gap-1 mt-1 text-xs text-green-600">
                    <ArrowUp className="w-3 h-3" />
                    {stats.weeklyGrowth.users}%
                  </div>
                )}
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">
                  <AnimatedCounter value={stats.recipesThisWeek || 0} />
                </div>
                <div className="text-sm text-purple-800">This Week</div>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-orange-100 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-orange-600">
                  <AnimatedCounter value={stats.totalRatings || 0} />
                </div>
                <div className="text-sm text-orange-800">Total Ratings</div>
                {stats.weeklyGrowth?.ratings && (
                  <div className="flex items-center justify-center gap-1 mt-1 text-xs text-green-600">
                    <ArrowUp className="w-3 h-3" />
                    {stats.weeklyGrowth.ratings}%
                  </div>
                )}
              </div>
            </div>

            {/* Top Contributors */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-md font-semibold mb-3 flex items-center gap-2">
                  <Award className="w-4 h-4 text-yellow-500" />
                  Top Chefs
                </h4>
                <div className="space-y-2">
                  {stats.topChefs?.map((chef, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{chef.avatar}</span>
                        <div>
                          <div className="font-medium text-gray-900">{chef.name}</div>
                          <div className="text-sm text-gray-600">{chef.recipes} recipes</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-yellow-500">
                        <Trophy className="w-4 h-4" />
                        <span className="text-sm font-medium">#{index + 1}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="text-md font-semibold mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-red-500" />
                  Popular Recipes
                </h4>
                <div className="space-y-2">
                  {stats.popularRecipes?.map((recipe, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-medium text-gray-900 text-sm">{recipe.title}</div>
                        <div className="text-xs text-gray-600">{formatNumber(recipe.views)} views</div>
                      </div>
                      <div className="flex items-center gap-1 text-red-500">
                        <Eye className="w-4 h-4" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundaryWrapper>
  );
};

// 9. LanguageSelector - Multi-language support
export const LanguageSelector = ({ 
  currentLanguage = 'en', 
  onLanguageChange, 
  availableLanguages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' },
    { code: 'ko', name: '한국어', flag: '🇰🇷' },
    { code: 'zh', name: '中文', flag: '🇨🇳' }
  ]
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(currentLanguage);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef(null);

  const currentLang = availableLanguages.find(lang => lang.code === selectedLanguage) || availableLanguages[0];

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (!isOpen) return;

      if (event.key === 'Escape') {
        setIsOpen(false);
        setSearchTerm('');
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  // Load saved language preference
  useEffect(() => {
    const savedLanguage = localStorage.getItem('preferredLanguage');
    if (savedLanguage && availableLanguages.some(lang => lang.code === savedLanguage)) {
      setSelectedLanguage(savedLanguage);
    } else {
      // Fallback to browser language
      const browserLang = navigator.language.split('-')[0];
      const matchingLang = availableLanguages.find(lang => lang.code === browserLang);
      if (matchingLang) {
        setSelectedLanguage(matchingLang.code);
      }
    }
  }, [availableLanguages]);

  const handleLanguageChange = async (languageCode) => {
    if (languageCode === selectedLanguage) return;
    
    setLoading(true);
    setIsOpen(false);
    setSearchTerm('');

    try {
      // Simulate loading translation resources
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setSelectedLanguage(languageCode);
      localStorage.setItem('preferredLanguage', languageCode);
      
      // Update document direction for RTL languages
      const rtlLanguages = ['ar', 'he', 'fa'];
      document.dir = rtlLanguages.includes(languageCode) ? 'rtl' : 'ltr';
      
      onLanguageChange?.(languageCode);
      
    } catch (error) {
      console.error('Error changing language:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredLanguages = availableLanguages.filter(lang =>
    lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lang.code.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <ErrorBoundaryWrapper>
      <div className="relative" ref={dropdownRef}>
        {/* Language Selector Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          disabled={loading}
          className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          aria-label="Select language"
          aria-expanded={isOpen}
        >
          <span className="text-lg">{currentLang.flag}</span>
          <span className="text-sm font-medium text-gray-700">
            {currentLang.name}
          </span>
          {loading ? (
            <Loader className="w-4 h-4 animate-spin text-gray-400" />
          ) : (
            <Languages className="w-4 h-4 text-gray-400" />
          )}
        </button>

        {/* Dropdown Menu */}
        {isOpen && (
          <div className="absolute top-full right-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
            {/* Search Input */}
            <div className="p-3 border-b border-gray-200">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search languages..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Language Options */}
            <div className="max-h-60 overflow-y-auto">
              {filteredLanguages.length > 0 ? (
                filteredLanguages.map(language => (
                  <button
                    key={language.code}
                    onClick={() => handleLanguageChange(language.code)}
                    className={`w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors flex items-center gap-3 ${
                      selectedLanguage === language.code ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                    }`}
                  >
                    <span className="text-lg">{language.flag}</span>
                    <div className="flex-1">
                      <div className="font-medium">{language.name}</div>
                      <div className="text-xs text-gray-500">{language.code.toUpperCase()}</div>
                    </div>
                    {selectedLanguage === language.code && (
                      <CheckCircle className="w-4 h-4 text-blue-500" />
                    )}
                  </button>
                ))
              ) : (
                <div className="px-4 py-8 text-center text-gray-500">
                  <Globe className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">No languages found</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-gray-200 bg-gray-50">
              <p className="text-xs text-gray-600 text-center">
                Translation quality may vary. Help us improve by reporting issues.
              </p>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundaryWrapper>
  );
};

// =====================================================
// ENHANCED COMPONENTS - Missing imports and components
// =====================================================

// Enhanced Components Library
// Following the Professional UI Enhancement Implementation Guide
// All components are additive layers that don't disrupt existing functionality


// =====================================================
// ERROR BOUNDARY WRAPPER - Critical for stability
// =====================================================
export const ErrorBoundaryWrapper = ({ children, fallback }) => {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const handleError = (error, errorInfo) => {
      console.error('Enhanced component error:', error, errorInfo);
      setHasError(true);
    };

    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return fallback || (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
        <p className="text-red-600">Enhanced feature temporarily unavailable</p>
        <button 
          onClick={() => setHasError(false)}
          className="mt-2 px-3 py-1 bg-red-100 text-red-700 rounded text-sm hover:bg-red-200"
        >
          Retry
        </button>
      </div>
    );
  }

  return children;
};

// =====================================================
// SMART SEARCH BAR - AI-powered with fallbacks
// =====================================================
export const EnhancedSearchBar = ({ onSearch, userPreferences = {} }) => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isListening, setIsListening] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);
  const [filters, setFilters] = useState({
    cuisine: '',
    difficulty: '',
    maxTime: '',
    dietary: ''
  });

  // Voice search implementation with fallbacks
  const handleVoiceSearch = useCallback(() => {
    try {
      if (!('webkitSpeechRecognition' in window)) {
        alert('Voice search not supported in your browser');
        return;
      }

      const recognition = new window.webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;

      if (isListening) {
        recognition.stop();
        setIsListening(false);
        return;
      }

      recognition.start();
      setIsListening(true);

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        setQuery(transcript);
        handleSearch(transcript);
        setIsListening(false);
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        // Fallback to text input
      };

      recognition.onend = () => {
        setIsListening(false);
      };
    } catch (error) {
      console.error('Voice search error:', error);
      setIsListening(false);
    }
  }, [isListening]);

  // Smart search with AI suggestions (with fallback)
  const handleSearch = useCallback(async (searchQuery = query) => {
    try {
      if (!searchQuery.trim()) return;

      // Save to recent searches
      const newRecentSearches = [searchQuery, ...recentSearches.filter(s => s !== searchQuery)].slice(0, 5);
      setRecentSearches(newRecentSearches);
      sessionStorage.setItem('recentSearches', JSON.stringify(newRecentSearches));

      // Enhanced search with filters
      onSearch(searchQuery, filters);

      // Try to get AI suggestions (with fallback)
      try {
        await getSuggestions(searchQuery);
      } catch (suggestionError) {
        console.warn('AI suggestions failed, using basic search');
        // Fallback to basic search - already handled by onSearch above
      }
    } catch (error) {
      console.error('Search error:', error);
      // Graceful fallback - search still works
      onSearch(searchQuery, {});
    }
  }, [query, filters, recentSearches, onSearch]);

  // AI-powered suggestions with fallback
  const getSuggestions = useCallback(async (searchQuery) => {
    try {
      // Simulate AI suggestion API call
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const mockSuggestions = [
        `${searchQuery} recipe`,
        `Easy ${searchQuery}`,
        `Healthy ${searchQuery}`,
        `Quick ${searchQuery}`,
      ];
      
      setSuggestions(mockSuggestions);
    } catch (error) {
      console.error('Suggestions error:', error);
      setSuggestions([]);
    }
  }, []);

  // Load recent searches on mount
  useEffect(() => {
    try {
      const saved = sessionStorage.getItem('recentSearches');
      if (saved) {
        setRecentSearches(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Error loading recent searches:', error);
    }
  }, []);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
      {/* Main search input */}
      <div className="flex gap-4 mb-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search recipes, ingredients, or cuisines..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
          <button
            onClick={handleVoiceSearch}
            className={`absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded-full transition-colors ${
              isListening ? 'text-red-500 animate-pulse' : 'text-gray-400 hover:text-orange-500'
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
        </div>
        
        <button
          onClick={() => handleSearch()}
          className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium"
        >
          Search
        </button>
        
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="px-4 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
        >
          <Filter className="w-5 h-5" />
        </button>
      </div>

      {/* Search suggestions */}
      {suggestions.length > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => {
                  setQuery(suggestion);
                  handleSearch(suggestion);
                }}
                className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-orange-100 hover:text-orange-600 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Recent searches */}
      {recentSearches.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Recent Searches</h4>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((search, index) => (
              <button
                key={index}
                onClick={() => {
                  setQuery(search);
                  handleSearch(search);
                }}
                className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-sm hover:bg-blue-100 transition-colors"
              >
                {search}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Advanced filters */}
      {showFilters && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t">
          <select
            value={filters.cuisine}
            onChange={(e) => setFilters(prev => ({ ...prev, cuisine: e.target.value }))}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
          >
            <option value="">All Cuisines</option>
            <option value="Indian">Indian</option>
            <option value="Italian">Italian</option>
            <option value="Chinese">Chinese</option>
            <option value="Mexican">Mexican</option>
          </select>

          <select
            value={filters.difficulty}
            onChange={(e) => setFilters(prev => ({ ...prev, difficulty: e.target.value }))}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
          >
            <option value="">All Levels</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>

          <select
            value={filters.maxTime}
            onChange={(e) => setFilters(prev => ({ ...prev, maxTime: e.target.value }))}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
          >
            <option value="">Any Time</option>
            <option value="30">Under 30 min</option>
            <option value="60">Under 1 hour</option>
            <option value="120">Under 2 hours</option>
          </select>

          <select
            value={filters.dietary}
            onChange={(e) => setFilters(prev => ({ ...prev, dietary: e.target.value }))}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
          >
            <option value="">All Dietary</option>
            <option value="vegetarian">Vegetarian</option>
            <option value="vegan">Vegan</option>
            <option value="gluten-free">Gluten Free</option>
            <option value="keto">Keto</option>
          </select>
        </div>
      )}
    </div>
  );
};

// 3. SmartFilterPanel - Advanced filtering with faceted search
export const SmartFilterPanel = ({ filters = {}, onFilterChange, onClearAll }) => {
  const [activeFilters, setActiveFilters] = useState(filters);
  const [isExpanded, setIsExpanded] = useState(false);
  const [filterCounts, setFilterCounts] = useState({});
  const [searchInFilters, setSearchInFilters] = useState('');
  const [savedFilters, setSavedFilters] = useState([]);

  // Filter options with counts
  const filterOptions = {
    cuisine: [
      { value: 'italian', label: 'Italian', count: 45 },
      { value: 'chinese', label: 'Chinese', count: 32 },
      { value: 'mexican', label: 'Mexican', count: 28 },
      { value: 'indian', label: 'Indian', count: 24 },
      { value: 'thai', label: 'Thai', count: 18 }
    ],
    difficulty: [
      { value: 'easy', label: 'Easy', count: 67 },
      { value: 'medium', label: 'Medium', count: 43 },
      { value: 'hard', label: 'Hard', count: 15 }
    ],
    cookTime: [
      { value: '0-15', label: 'Under 15 min', count: 23 },
      { value: '15-30', label: '15-30 min', count: 56 },
      { value: '30-60', label: '30-60 min', count: 34 },
      { value: '60+', label: 'Over 1 hour', count: 12 }
    ],
    dietary: [
      { value: 'vegetarian', label: 'Vegetarian', count: 78 },
      { value: 'vegan', label: 'Vegan', count: 45 },
      { value: 'gluten-free', label: 'Gluten Free', count: 34 },
      { value: 'keto', label: 'Keto', count: 28 },
      { value: 'dairy-free', label: 'Dairy Free', count: 31 }
    ]
  };

  // Filter presets
  const filterPresets = [
    { name: 'Quick & Easy', filters: { difficulty: 'easy', cookTime: '0-30' } },
    { name: 'Healthy Options', filters: { dietary: 'vegetarian', cookTime: '0-60' } },
    { name: 'Weekend Projects', filters: { difficulty: 'hard', cookTime: '60+' } }
  ];

  useEffect(() => {
    // Load saved filters from sessionStorage
    const saved = sessionStorage.getItem('savedFilters');
    if (saved) {
      try {
        setSavedFilters(JSON.parse(saved));
      } catch (error) {
        console.error('Error loading saved filters:', error);
      }
    }
  }, []);

  const handleFilterToggle = (category, value) => {
    const currentValues = activeFilters[category] || [];
    const isSelected = Array.isArray(currentValues) 
      ? currentValues.includes(value)
      : currentValues === value;

    let newValues;
    if (category === 'difficulty' || category === 'cookTime') {
      // Single selection for these categories
      newValues = isSelected ? '' : value;
    } else {
      // Multiple selection for others
      newValues = isSelected 
        ? currentValues.filter(v => v !== value)
        : [...(Array.isArray(currentValues) ? currentValues : []), value];
    }

    const newFilters = { ...activeFilters, [category]: newValues };
    setActiveFilters(newFilters);
    onFilterChange(newFilters);
  };

  const handleClearAll = () => {
    setActiveFilters({});
    setSearchInFilters('');
    onClearAll();
  };

  const applyPreset = (preset) => {
    setActiveFilters(preset.filters);
    onFilterChange(preset.filters);
  };

  const saveCurrentFilters = () => {
    const filterName = prompt('Name for this filter set:');
    if (filterName && Object.keys(activeFilters).length > 0) {
      const newSaved = [...savedFilters, { name: filterName, filters: activeFilters }];
      setSavedFilters(newSaved);
      sessionStorage.setItem('savedFilters', JSON.stringify(newSaved));
    }
  };

  const getActiveFilterCount = () => {
    return Object.values(activeFilters).reduce((count, value) => {
      if (Array.isArray(value)) return count + value.length;
      return count + (value ? 1 : 0);
    }, 0);
  };

  const filteredOptions = (options) => {
    if (!searchInFilters) return options;
    return options.filter(option => 
      option.label.toLowerCase().includes(searchInFilters.toLowerCase())
    );
  };

  return (
    <ErrorBoundaryWrapper>
      <div className="bg-white rounded-xl shadow-lg p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Filter className="w-5 h-5 text-blue-500" />
              Smart Filters
            </h3>
            {getActiveFilterCount() > 0 && (
              <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-sm font-medium">
                {getActiveFilterCount()} active
              </span>
            )}
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
              aria-label={isExpanded ? 'Collapse filters' : 'Expand filters'}
            >
              {isExpanded ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
            </button>
            
            <button
              onClick={handleClearAll}
              className="text-sm text-red-600 hover:text-red-700 transition-colors"
              disabled={getActiveFilterCount() === 0}
            >
              Clear All
            </button>
          </div>
        </div>

        {/* Compact Filter Display */}
        {!isExpanded && getActiveFilterCount() > 0 && (
          <div className="flex flex-wrap gap-2">
            {Object.entries(activeFilters).map(([category, value]) => {
              if (!value || (Array.isArray(value) && value.length === 0)) return null;
              
              const values = Array.isArray(value) ? value : [value];
              return values.map(val => (
                <span
                  key={`${category}-${val}`}
                  className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs"
                >
                  {filterOptions[category]?.find(opt => opt.value === val)?.label || val}
                  <button
                    onClick={() => handleFilterToggle(category, val)}
                    className="text-blue-600 hover:text-blue-800"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ));
            })}
          </div>
        )}

        {/* Search within filters */}
        {isExpanded && (
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search filters..."
                value={searchInFilters}
                onChange={(e) => setSearchInFilters(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
              />
            </div>
          </div>
        )}

        {/* Filter Presets */}
        <div className="mb-6">
          <h4 className="text-sm font-medium text-gray-700 mb-3">Quick Filters</h4>
          <div className="flex flex-wrap gap-2">
            {filterPresets.map(preset => (
              <button
                key={preset.name}
                onClick={() => applyPreset(preset)}
                className="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-blue-100 hover:text-blue-700 transition-colors text-sm"
              >
                {preset.name}
              </button>
            ))}
            
            {Object.keys(activeFilters).length > 0 && (
              <button
                onClick={saveCurrentFilters}
                className="px-3 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors text-sm flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                Save Current
              </button>
            )}
          </div>
          
          {/* Saved Filters */}
          {savedFilters.length > 0 && (
            <div className="mt-3">
              <h5 className="text-xs font-medium text-gray-600 mb-2">Saved Filters</h5>
              <div className="flex flex-wrap gap-2">
                {savedFilters.map((saved, index) => (
                  <button
                    key={index}
                    onClick={() => applyPreset(saved)}
                    className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full hover:bg-purple-200 transition-colors text-xs flex items-center gap-1"
                  >
                    {saved.name}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        const newSaved = savedFilters.filter((_, i) => i !== index);
                        setSavedFilters(newSaved);
                        sessionStorage.setItem('savedFilters', JSON.stringify(newSaved));
                      }}
                      className="ml-1 text-purple-500 hover:text-purple-700"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Filter Categories */}
        {isExpanded && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(filterOptions).map(([category, options]) => (
              <div key={category}>
                <h4 className="text-sm font-medium text-gray-700 mb-3 capitalize">
                  {category}
                </h4>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {filteredOptions(options).map(option => {
                    const isSelected = Array.isArray(activeFilters[category])
                      ? activeFilters[category].includes(option.value)
                      : activeFilters[category] === option.value;
                    
                    return (
                      <label key={option.value} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type={category === 'difficulty' || category === 'cookTime' ? 'radio' : 'checkbox'}
                          name={category === 'difficulty' || category === 'cookTime' ? category : undefined}
                          checked={isSelected}
                          onChange={() => handleFilterToggle(category, option.value)}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm text-gray-700 flex-1">{option.label}</span>
                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                          {option.count}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </ErrorBoundaryWrapper>
  );
};

// =====================================================
// KITCHEN MODE OVERLAY - Mobile-first, touch-friendly
// =====================================================
export const KitchenModeOverlay = ({ selectedRecipeId, onExit, recipes = [] }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [screenLocked, setScreenLocked] = useState(false);
  const wakeLockRef = useRef(null);

  const recipe = recipes.find(r => r.id === selectedRecipeId);

  // Screen wake lock for kitchen mode
  useEffect(() => {
    const requestWakeLock = async () => {
      try {
        if ('wakeLock' in navigator) {
          wakeLockRef.current = await navigator.wakeLock.request('screen');
          setScreenLocked(true);
        }
      } catch (error) {
        console.warn('Wake lock not supported or failed:', error);
      }
    };

    requestWakeLock();

    return () => {
      if (wakeLockRef.current) {
        wakeLockRef.current.release();
        setScreenLocked(false);
      }
    };
  }, []);

  // Timer functionality
  useEffect(() => {
    let interval;
    if (isTimerRunning && timer > 0) {
      interval = setInterval(() => {
        setTimer(prev => {
          if (prev <= 1) {
            setIsTimerRunning(false);
            // Play notification sound or vibrate
            if ('vibrate' in navigator) {
              navigator.vibrate([200, 100, 200]);
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timer, isTimerRunning]);

  // Voice feedback
  const speakText = useCallback((text) => {
    try {
      if (voiceEnabled && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.8;
        utterance.volume = 0.7;
        speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error('Speech synthesis error:', error);
    }
  }, [voiceEnabled]);

  const handleStepChange = (stepIndex) => {
    setCurrentStep(stepIndex);
    if (recipe && recipe.instructions) {
      speakText(recipe.instructions[stepIndex]);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!recipe) {
    return (
      <div className="fixed inset-0 bg-gray-900 z-50 flex items-center justify-center">
        <div className="text-white text-center">
          <ChefHat className="w-16 h-16 mx-auto mb-4" />
          <p>Recipe not found</p>
          <button
            onClick={onExit}
            className="mt-4 px-6 py-3 bg-orange-500 rounded-lg hover:bg-orange-600"
          >
            Exit Kitchen Mode
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-900 text-white z-50 overflow-auto">
      {/* Header */}
      <div className="bg-gray-800 p-4 flex items-center justify-between">
        <h1 className="text-xl font-bold truncate flex-1">{recipe.title}</h1>
        <div className="flex items-center gap-4">
          {/* Timer Display */}
          <div className="bg-gray-700 px-4 py-2 rounded-lg">
            <span className="text-2xl font-mono">{formatTime(timer)}</span>
          </div>
          
          {/* Voice Toggle */}
          <button
            onClick={() => setVoiceEnabled(!voiceEnabled)}
            className={`p-3 rounded-lg transition-colors ${
              voiceEnabled ? 'bg-green-600' : 'bg-gray-700'
            }`}
          >
            {voiceEnabled ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
          </button>

          {/* Exit Button */}
          <button
            onClick={onExit}
            className="p-3 bg-red-600 rounded-lg hover:bg-red-700 transition-colors"
          >
            ✕
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6">
        {/* Current Step Display */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">
              Step {currentStep + 1} of {recipe.instructions?.length || 0}
            </h2>
            <div className="text-gray-400">
              {Math.round(((currentStep + 1) / (recipe.instructions?.length || 1)) * 100)}% Complete
            </div>
          </div>

          <div className="bg-gray-800 rounded-xl p-6 mb-6">
            <p className="text-lg leading-relaxed">
              {recipe.instructions?.[currentStep] || 'No instructions available'}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-700 rounded-full h-2 mb-6">
            <div 
              className="bg-orange-500 h-2 rounded-full transition-all duration-300"
              style={{ 
                width: `${((currentStep + 1) / (recipe.instructions?.length || 1)) * 100}%` 
              }}
            />
          </div>
        </div>

        {/* Timer Controls */}
        <div className="bg-gray-800 rounded-xl p-6 mb-6">
          <h3 className="text-lg font-semibold mb-4">Timer</h3>
          <div className="flex flex-wrap gap-3 mb-4">
            {[1, 5, 10, 15, 30].map(minutes => (
              <button
                key={minutes}
                onClick={() => {
                  setTimer(minutes * 60);
                  setIsTimerRunning(true);
                }}
                className="px-4 py-2 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
              >
                {minutes} min
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              disabled={timer === 0}
              className="flex-1 py-3 bg-green-600 rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isTimerRunning ? 'Pause' : 'Start'} Timer
            </button>
            <button
              onClick={() => {
                setTimer(0);
                setIsTimerRunning(false);
              }}
              className="px-6 py-3 bg-gray-600 rounded-lg hover:bg-gray-700 transition-colors"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Navigation Controls */}
        <div className="flex gap-4">
          <button
            onClick={() => handleStepChange(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            className="flex-1 py-4 bg-gray-700 rounded-xl hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-lg font-medium"
          >
            ← Previous Step
          </button>
          
          <button
            onClick={() => handleStepChange(Math.min((recipe.instructions?.length || 1) - 1, currentStep + 1))}
            disabled={currentStep === (recipe.instructions?.length || 1) - 1}
            className="flex-1 py-4 bg-orange-600 rounded-xl hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-lg font-medium"
          >
            Next Step →
          </button>
        </div>

        {/* Quick Actions */}
        <div className="mt-6 grid grid-cols-2 gap-4">
          <button
            onClick={() => speakText(recipe.instructions?.[currentStep] || '')}
            disabled={!voiceEnabled}
            className="p-4 bg-purple-600 rounded-xl hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
          >
            <Volume2 className="w-5 h-5" />
            Repeat Step
          </button>
          
          <button
            onClick={() => {
              if (currentStep === (recipe.instructions?.length || 1) - 1) {
                speakText('Congratulations! You have completed the recipe!');
              }
            }}
            className="p-4 bg-green-600 rounded-xl hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
          >
            <Trophy className="w-5 h-5" />
            {currentStep === (recipe.instructions?.length || 1) - 1 ? 'Complete!' : 'Mark Done'}
          </button>
        </div>
      </div>
    </div>
  );
};

// =====================================================
// PERSONALIZATION DASHBOARD - AI-driven recommendations
// =====================================================
export const PersonalizationDashboard = ({ preferences = {}, onUpdatePreferences, onRecipeClick }) => {
  const [skillLevel, setSkillLevel] = useState(preferences.skillLevel || 'intermediate');
  const [dietaryRestrictions, setDietaryRestrictions] = useState(preferences.dietary || []);
  const [favoritesCuisines, setFavoriteCuisines] = useState(preferences.cuisines || []);
  const [cookingGoals, setCookingGoals] = useState(preferences.goals || []);
  const [personalizedRecipes, setPersonalizedRecipes] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [weeklyProgress, setWeeklyProgress] = useState({
    recipesCooked: 3,
    goal: 7,
    caloriesSaved: 450,
    newSkillsLearned: 2
  });

  // Load personalized recommendations
  useEffect(() => {
    const loadPersonalizedContent = async () => {
      try {
        // Simulate AI-powered personalization
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Mock personalized recipes based on preferences
        const mockPersonalized = [
          {
            id: 'p1',
            title: 'Recommended: Quick Healthy Stir Fry',
            reason: 'Based on your healthy eating goal',
            difficulty: skillLevel,
            matchScore: 95
          },
          {
            id: 'p2', 
            title: 'Try Next: ' + (favoritesCuisines[0] || 'Asian') + ' Fusion Dish',
            reason: 'Matches your favorite cuisine',
            difficulty: skillLevel,
            matchScore: 88
          }
        ];
        
        setPersonalizedRecipes(mockPersonalized);

        // Mock achievements
        setAchievements([
          { id: 1, title: 'First Recipe Completed', earned: true, icon: '🍳' },
          { id: 2, title: 'Healthy Week', earned: weeklyProgress.recipesCooked >= 5, icon: '🥗' },
          { id: 3, title: 'Skill Builder', earned: weeklyProgress.newSkillsLearned >= 3, icon: '📚' }
        ]);
      } catch (error) {
        console.error('Error loading personalized content:', error);
      }
    };

    loadPersonalizedContent();
  }, [skillLevel, dietaryRestrictions, favoritesCuisines, cookingGoals, weeklyProgress]);

  const handlePreferenceUpdate = (key, value) => {
    const newPreferences = { ...preferences, [key]: value };
    onUpdatePreferences(newPreferences);
  };

  return (
    <section className="py-16 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Your Culinary Journey
          </h2>
          <p className="text-xl text-gray-600">
            Personalized recommendations just for you
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Weekly Progress */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Weekly Progress
            </h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>Recipes Cooked</span>
                  <span>{weeklyProgress.recipesCooked}/{weeklyProgress.goal}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full transition-all"
                    style={{ width: `${(weeklyProgress.recipesCooked / weeklyProgress.goal) * 100}%` }}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-orange-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-orange-600">{weeklyProgress.caloriesSaved}</div>
                  <div className="text-xs text-orange-800">Calories Saved</div>
                </div>
                <div className="bg-blue-50 rounded-lg p-3">
                  <div className="text-2xl font-bold text-blue-600">{weeklyProgress.newSkillsLearned}</div>
                  <div className="text-xs text-blue-800">Skills Learned</div>
                </div>
              </div>
            </div>
          </div>

          {/* Skill Assessment */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <User className="w-5 h-5 text-blue-500" />
              Cooking Profile
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Skill Level</label>
                <select
                  value={skillLevel}
                  onChange={(e) => {
                    setSkillLevel(e.target.value);
                    handlePreferenceUpdate('skillLevel', e.target.value);
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                  <option value="expert">Expert Chef</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Dietary Preferences</label>
                <div className="flex flex-wrap gap-2">
                  {['vegetarian', 'vegan', 'gluten-free', 'keto'].map(diet => (
                    <button
                      key={diet}
                      onClick={() => {
                        const newDietary = dietaryRestrictions.includes(diet)
                          ? dietaryRestrictions.filter(d => d !== diet)
                          : [...dietaryRestrictions, diet];
                        setDietaryRestrictions(newDietary);
                        handlePreferenceUpdate('dietary', newDietary);
                      }}
                      className={`px-3 py-1 rounded-full text-sm transition-colors ${
                        dietaryRestrictions.includes(diet)
                          ? 'bg-green-100 text-green-800'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {diet}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-500" />
              Achievements
            </h3>
            
            <div className="space-y-3">
              {achievements.map(achievement => (
                <div 
                  key={achievement.id}
                  className={`flex items-center gap-3 p-3 rounded-lg ${
                    achievement.earned 
                      ? 'bg-yellow-50 border border-yellow-200' 
                      : 'bg-gray-50 border border-gray-200'
                  }`}
                >
                  <div className="text-2xl">{achievement.icon}</div>
                  <div className="flex-1">
                    <div className={`font-medium ${
                      achievement.earned ? 'text-yellow-800' : 'text-gray-600'
                    }`}>
                      {achievement.title}
                    </div>
                  </div>
                  {achievement.earned && (
                    <div className="text-yellow-600">✓</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Personalized Recommendations */}
        <div className="bg-white rounded-2xl p-8 shadow-lg">
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Zap className="w-6 h-6 text-orange-500" />
            Recommended For You
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {personalizedRecipes.map(recipe => (
              <div 
                key={recipe.id} 
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => onRecipeClick?.(recipe)}
              >
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-semibold text-gray-900">{recipe.title}</h4>
                  <div className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                    {recipe.matchScore}% match
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-3">{recipe.reason}</p>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                    {recipe.difficulty}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// =====================================================
// OFFLINE MANAGER - PWA functionality with fallbacks
// =====================================================
export const OfflineManager = ({ onStatusChange }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [offlineRecipes, setOfflineRecipes] = useState([]);
  const [syncStatus, setSyncStatus] = useState('synced');

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setSyncStatus('syncing');
      onStatusChange?.(true);
      
      // Attempt to sync offline data
      setTimeout(() => {
        setSyncStatus('synced');
      }, 2000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      setSyncStatus('offline');
      onStatusChange?.(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [onStatusChange]);

  // Service worker registration with fallbacks
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => {
          console.log('SW registered:', registration);
        })
        .catch(error => {
          console.warn('SW registration failed:', error);
        });
    }
  }, []);

  const downloadForOffline = async (recipes) => {
    try {
      const recipesToCache = recipes.slice(0, 10); // Limit offline storage
      setOfflineRecipes(recipesToCache);
      localStorage.setItem('offlineRecipes', JSON.stringify(recipesToCache));
    } catch (error) {
      console.error('Error caching recipes offline:', error);
    }
  };

  if (!isOnline) {
    return (
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-3">
          <WifiOff className="w-5 h-5 text-yellow-600" />
          <div className="flex-1">
            <h4 className="font-medium text-yellow-800">You're offline</h4>
            <p className="text-yellow-700 text-sm">
              Showing cached recipes. Some features may be limited.
            </p>
          </div>
          <div className="text-yellow-600">
            {offlineRecipes.length} recipes available
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
      <div className="flex items-center gap-2 text-green-700">
        <Wifi className="w-4 h-4" />
        <span className="text-sm font-medium">
          {syncStatus === 'syncing' ? 'Syncing...' : 'Connected'}
        </span>
        {syncStatus === 'syncing' && (
          <Loader className="w-4 h-4 animate-spin" />
        )}
      </div>
    </div>
  );
};

// =====================================================
// SMART RECOMMENDATION ENGINE - AI-powered suggestions
// =====================================================
export const SmartRecommendationEngine = ({ userHistory = [], preferences = {}, onRecommendation }) => {
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [recommendationType, setRecommendationType] = useState('trending');

  const recommendationTypes = {
    trending: 'Trending Now',
    personal: 'For You',
    seasonal: 'Seasonal Picks',
    quick: 'Quick & Easy',
    healthy: 'Healthy Options'
  };

  useEffect(() => {
    generateRecommendations();
  }, [recommendationType, userHistory, preferences]);

  const generateRecommendations = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock AI recommendations based on type
      const mockRecommendations = {
        trending: [
          { id: 't1', title: 'Viral TikTok Pasta', popularity: 95, reason: 'Trending on social media' },
          { id: 't2', title: 'Cloud Bread Recipe', popularity: 88, reason: 'Most searched this week' }
        ],
        personal: [
          { id: 'p1', title: 'Mediterranean Bowl', matchScore: 94, reason: 'Based on your Italian preferences' },
          { id: 'p2', title: 'Quinoa Stir Fry', matchScore: 89, reason: 'Matches your healthy eating goals' }
        ],
        seasonal: [
          { id: 's1', title: 'Autumn Squash Soup', seasonal: true, reason: 'Perfect for fall weather' },
          { id: 's2', title: 'Pumpkin Spice Cookies', seasonal: true, reason: 'Seasonal favorite' }
        ],
        quick: [
          { id: 'q1', title: '15-Min Chicken Teriyaki', time: 15, reason: 'Ready in 15 minutes' },
          { id: 'q2', title: '10-Min Avocado Toast', time: 10, reason: 'Perfect for busy mornings' }
        ],
        healthy: [
          { id: 'h1', title: 'Green Goddess Salad', calories: 245, reason: 'Low calorie, high nutrition' },
          { id: 'h2', title: 'Protein Power Bowl', protein: 25, reason: 'High protein content' }
        ]
      };
      
      setRecommendations(mockRecommendations[recommendationType] || []);
    } catch (error) {
      console.error('Error generating recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ErrorBoundaryWrapper>
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-500" />
            Smart Recommendations
          </h3>
          
          <select
            value={recommendationType}
            onChange={(e) => setRecommendationType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
          >
            {Object.entries(recommendationTypes).map(([key, label]) => (
              <option key={key} value={key}>{label}</option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="text-center py-8">
            <Loader className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-500" />
            <p className="text-gray-600">Generating personalized recommendations...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recommendations.map(recipe => (
              <div 
                key={recipe.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => onRecommendation?.(recipe)}
              >
                <h4 className="font-semibold text-gray-900 mb-2">{recipe.title}</h4>
                <p className="text-gray-600 text-sm mb-3">{recipe.reason}</p>
                <div className="flex items-center gap-2">
                  {recipe.popularity && (
                    <span className="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">
                      {recipe.popularity}% popular
                    </span>
                  )}
                  {recipe.matchScore && (
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                      {recipe.matchScore}% match
                    </span>
                  )}
                  {recipe.time && (
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                      {recipe.time} min
                    </span>
                  )}
                  {recipe.calories && (
                    <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs">
                      {recipe.calories} cal
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </ErrorBoundaryWrapper>
  );
};

// =====================================================
// ENHANCED RECIPE CARD - Interactive with rich features
// =====================================================
export const EnhancedRecipeCard = ({ recipe, onSave, onShare, onView, onClick }) => {
  const [isBookmarked, setIsBookmarked] = useState(recipe.isBookmarked || false);
  const [rating, setRating] = useState(recipe.userRating || 0);
  const [showNutrition, setShowNutrition] = useState(false);

  const handleBookmark = (e) => {
    e.stopPropagation();
    setIsBookmarked(!isBookmarked);
    onSave?.(recipe.id, !isBookmarked);
  };

  const handleRating = (newRating, e) => {
    e.stopPropagation();
    setRating(newRating);
    // Mock API call to save rating
  };

  const handleShare = (e) => {
    e.stopPropagation();
    onShare?.(recipe);
  };
   return (
    <ErrorBoundaryWrapper>
      <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer">
        {/* Image Section */}
        <div className="relative h-48 bg-gradient-to-r from-orange-400 to-red-500">
          <div className="absolute inset-0 flex items-center justify-center">
            <ChefHat className="w-12 h-12 text-white opacity-50" />
          </div>
          
          {/* Quick Actions Overlay */}
          <div className="absolute top-4 right-4 flex gap-2">
            <button
              onClick={handleBookmark}
              className={`p-2 rounded-full transition-colors ${
                isBookmarked 
                  ? 'bg-red-500 text-white' 
                  : 'bg-white/80 text-gray-700 hover:bg-white'
              }`}
            >
              <Heart className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>
            
            <button
              onClick={handleShare}
              className="p-2 bg-white/80 text-gray-700 rounded-full hover:bg-white transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
          
          {/* Recipe Tags */}
          <div className="absolute bottom-4 left-4 flex gap-2">
            {recipe.difficulty && (
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                recipe.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                recipe.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>
                {recipe.difficulty}
              </span>
            )}
            {recipe.cookTime && (
              <span className="bg-white/90 text-gray-800 px-2 py-1 rounded text-xs font-medium flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {recipe.cookTime}m
              </span>
            )}
          </div>
        </div>

        {/* Content Section */}
        <div className="p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2">
            {recipe.title}
          </h3>
          
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {recipe.description || 'Delicious recipe that you\'ll love to cook and share with family.'}
          </p>

          {/* Recipe Stats */}
          <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
            <div className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              <span>{recipe.servings || 4} servings</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Eye className="w-4 h-4" />
              <span>{recipe.views || 0} views</span>
            </div>

            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-current text-yellow-500" />
              <span>{recipe.rating || 4.5}</span>
            </div>
          </div>

          {/* Interactive Rating */}
          <div className="flex items-center gap-2 mb-4">
            <span className="text-sm text-gray-600">Your rating:</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map(star => (
                <button
                  key={star}
                  onClick={(e) => handleRating(star, e)}
                  className={`text-lg transition-colors ${
                    star <= rating ? 'text-yellow-500' : 'text-gray-300 hover:text-yellow-400'
                  }`}
                >
                  <Star className={`w-4 h-4 ${star <= rating ? 'fill-current' : ''}`} />
                </button>
              ))}
            </div>
          </div>

          {/* Nutrition Toggle */}
          {recipe.nutrition && (
            <div className="mb-4">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowNutrition(!showNutrition);
                }}
                className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1"
              >
                Nutrition Info
                {showNutrition ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
              </button>
              
              {showNutrition && (
                <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">{recipe.nutrition?.calories || 250}</div>
                      <div className="text-gray-600">Calories</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">{recipe.nutrition?.protein || 12}g</div>
                      <div className="text-gray-600">Protein</div>
                    </div>
                    <div className="text-center">
                      <div className="font-semibold text-gray-900">{recipe.nutrition?.carbs || 30}g</div>
                      <div className="text-gray-600">Carbs</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            <button
              onClick={(e) => { e.stopPropagation(); if (onView) onView(recipe); else onClick?.(recipe.id); }}
              className="flex-1 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors font-medium text-sm"
            >
              View Recipe
            </button>
            
            <button
              onClick={(e) => {
                e.stopPropagation();
                // Mock add to meal plan functionality
                console.log('Added to meal plan:', recipe.title);
              }}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <Calendar className="w-4 h-4" />
            </button>
            
            <button
              onClick={(e) => {
                e.stopPropagation();
                // Mock add to shopping list functionality
                console.log('Added to shopping list:', recipe.title);
              }}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <ShoppingCart className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </ErrorBoundaryWrapper>
  )};